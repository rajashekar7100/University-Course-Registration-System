/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servelet;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author rajashekar
 */
public class CoursesRegistered implements Serializable{
    
    public ArrayList<String> courses=new ArrayList<String>();
   
}
